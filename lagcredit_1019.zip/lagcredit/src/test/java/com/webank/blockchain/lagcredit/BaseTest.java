package com.webank.blockchain.lagcredit;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.Test;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = LagcreditApplication.class)
public class BaseTest {
    @Test
    public void test(){
    }
}

