package com.webank.blockchain.lagcredit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LagcreditApplication {

	public static void main(String[] args) {
		SpringApplication.run(LagcreditApplication.class, args);
	}

}
